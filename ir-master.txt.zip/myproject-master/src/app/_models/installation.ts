/* * * ./app/comments/model/comment.ts * * */
export class Installation {
    constructor(
        public AccountName: string,
        public City:string,
        public Country:string,
        public County:string,
        public SerialNumber:number,
        public State:string,
        public Street:string,
        public ZipCode:number
        ){}
}
