npm install
npm install @angular/material
npm install --save lodash
npm install --save ngx-dropdown
npm install --save angular2-datatable
