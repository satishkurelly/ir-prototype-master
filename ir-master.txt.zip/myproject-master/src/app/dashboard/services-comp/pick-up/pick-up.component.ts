import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'pick-up',
  templateUrl: 'pick-up.component.html'
})
export class PickUpComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
