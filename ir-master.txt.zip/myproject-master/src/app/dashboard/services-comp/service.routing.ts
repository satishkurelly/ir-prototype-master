import {PsWebComponent} from "./ps-web/ps-web.component";
import {PickUpComponent} from "./pick-up/pick-up.component";
import {InvoiceComponent} from "./invoice-mgmt/invoice.component";
import {AuthorizationComponent} from "./authorizations/authorization.component";

import { Route } from '@angular/router';

export const ServiceRouting: Route[] = [
  { path: 'auth', component: AuthorizationComponent },
  { path: 'invoice', component: InvoiceComponent },
  { path: 'pick', component: PickUpComponent },
  { path: 'ps', component: PsWebComponent }
];


