export * from './ir-login.component';
