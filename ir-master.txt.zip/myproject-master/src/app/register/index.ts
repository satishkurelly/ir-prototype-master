export * from './ir-register.component';
