import {Component, OnInit} from '@angular/core';
import {Idle, DEFAULT_INTERRUPTSOURCES} from '@ng-idle/core';
import {Router} from '@angular/router';

@Component({
  selector: 'ir-dashboard',
  templateUrl: 'dashboard.component.html'
})

export class DashboardComponent{
  //nome = localStorage['nome'];
  model: any = {};
  timedOut: boolean = false;
  count: number = 0;
  IDLE_SECS:number = 10;//120;
  TIMEOUT_SEC:number = 360;//30;

  constructor(private router:Router, private idle:Idle) {
  }

  ngOnInit(){
    this.setupIdleWatch();
  }

  setupIdleWatch() {
    this.idle.setIdle(this.IDLE_SECS);
    this.idle.setTimeout(this.TIMEOUT_SEC);
    this.idle.setInterrupts(DEFAULT_INTERRUPTSOURCES);
    this.idle.onIdleEnd.subscribe(() => this.timedOut = false );
    this.idle.onTimeout.subscribe(() => {//this.timedOut = false;
      this.idle.stop();
      //console.log('Timeout');
      //localStorage.clear();
      this.router.navigate(["/login"]);
    });
    this.idle.onTimeoutWarning.subscribe((countdown) => {
      this.count = countdown;
      this.timedOut = true;

    });
    this.idle.watch();
  }
}
