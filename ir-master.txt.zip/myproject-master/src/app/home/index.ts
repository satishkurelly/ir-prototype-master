export * from './ir-home.component';
