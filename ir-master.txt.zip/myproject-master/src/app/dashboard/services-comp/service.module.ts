import {NgModule} from '@angular/core';
import {RouterModule} from "@angular/router";
import {PsWebComponent} from "./ps-web/ps-web.component";
import {PickUpComponent} from "./pick-up/pick-up.component";
import {InvoiceComponent} from "./invoice-mgmt/invoice.component";
import {AuthorizationComponent} from "./authorizations/authorization.component";


@NgModule({
  declarations: [
    AuthorizationComponent,
    InvoiceComponent,
    PickUpComponent,
    PsWebComponent
  ],
  imports: [
    RouterModule
  ],
  exports: [ AuthorizationComponent,
    InvoiceComponent,
    PickUpComponent,
    PsWebComponent],
  providers: [

  ],
})
export class ServiceModule {

  constructor() {
  }

}
