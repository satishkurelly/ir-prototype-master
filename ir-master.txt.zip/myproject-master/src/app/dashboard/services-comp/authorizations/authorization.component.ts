import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'authorizationComponent',
  templateUrl: 'authorization.component.html'
})
export class AuthorizationComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
