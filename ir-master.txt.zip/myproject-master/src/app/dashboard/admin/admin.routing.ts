import {UserProfileComponent} from "./user-profiles/user-profiles.component";
import {GroupsComponent} from "./groups/groups.component";

import { Route } from '@angular/router';


export const AdminRouting: Route[] = [
  {
    path: 'users-profile',
    component: UserProfileComponent
  },
  {
    path: 'groups',
    component: GroupsComponent
  },
];
