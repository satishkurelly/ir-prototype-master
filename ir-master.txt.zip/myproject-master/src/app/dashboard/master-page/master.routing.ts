import {AccountsDataComponent} from "./accounts/accounts.component";
import {RVMInfoComponent} from "./rvm-information/rvmInfo.component";
import { Route } from '@angular/router';


export const MasterRouting: Route[] = [
  {
    path: 'accounts',
    component: AccountsDataComponent
  },
  {
    path: 'rvm',
    component: RVMInfoComponent
  },
];
